/home/zzc/donkey/src/matching /home/zzc/donkey/src/sample.list 132 329 &> /home/zzc/donkey/src/matching.log
