#ifndef VCF_H
#define VCF_H

#include <iostream>
#include <fstream>
#include <string>

using namespace std;

class VCF {
    
public:

    VCF();
    ~VCF();

private:


#endif
